<?xml version="1.0" encoding="UTF-8"?>
<tileset name="DungeonTilesetSprite" tilewidth="8" tileheight="8" tilecount="136" columns="8">
 <image source="Graphic Revision Tileset 02.png" trans="898989" width="64" height="136"/>
</tileset>
